﻿namespace AppTest;

public partial class TestPage : ContentPage
{
	public TestPage()
	{
		InitializeComponent();
	}
}
